package Paint;

import javax.swing.*;

public class Test_Paint {
    public static void main(String[] args) {
        //创建窗体
        JFrame jf = new JFrame();
        //设置窗体名字
        jf.setTitle("画图板");
        //设置窗体大小
        jf.setSize(600, 600);
        //设置窗体居中
        jf.setLocationRelativeTo(null);
        //设置窗体可见
        jf.setVisible(true);
        //设置默认关闭形式
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
