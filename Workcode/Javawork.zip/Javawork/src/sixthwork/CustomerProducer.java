package sixthwork;

import java.util.concurrent.*;

public class CustomerProducer {

    public static void main(String[] args) {
        BlockingQueue<String> q=new ArrayBlockingQueue<String>(1);
        String []s=new String[] {"producer","customer","warehouse","inversion","thread"};
        Thread P=new Thread(new Producer(q,s));
        Thread C=new Thread(new Consumer(q));
        P.start();
        C.start();
    }

}
//生产者进程
class Producer implements Runnable
{
    private BlockingQueue<String>q=null;
    String []stringArray=new String[5];

    public Producer(BlockingQueue<String>q,String[]stringArray)
    {
        this.q=q;
        this.stringArray=stringArray;
    }

    public void run()
    {
        int i=0;
        while(i < 5)
        {
            try
            {
                String s=new String(stringArray[i]);
                q.put(s);
                //System.out.println(s);
                Thread.sleep(100);
            }
            catch(InterruptedException e)
            {
                e.printStackTrace();
            }
            i++;
        }
    }
}
//消费者进程
class Consumer implements Runnable
{
    private BlockingQueue<String>q=null;

    public Consumer(BlockingQueue<String>q)
    {
        this.q=q;
    }

    public void run()
    {
        int i=0;
        while(i<5)
        {
            try
            {
                StringBuffer reverseS=new StringBuffer(q.take()); //take:从队头获取元素，如果队列为空则阻塞直到队列有元素。
                reverseS.reverse();
                System.out.println(reverseS);
            }
            catch(InterruptedException e)
            {
                e.printStackTrace();
            }
            i++;
        }
    }
}