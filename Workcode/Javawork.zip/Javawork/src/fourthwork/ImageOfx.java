package fourthwork;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class ImageOfx
{
    public static void main(String[] args){
        DrawFrame frame=new DrawFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

class DrawFrame extends JFrame{
    public DrawFrame(){
        setTitle("Image of X^2");
        setSize(850,800);
        DrawPanel panel = new DrawPanel();
        add(panel);
    }
}
class DrawPanel extends JPanel
{
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);


        /**
         * 绘制网格
         */
        Graphics2D gridding = (Graphics2D) g;
        gridding.setColor(Color.blue);
        for (int i = 0; i <= 800; i += 50)
        {
            gridding.draw(new Line2D.Double(i, 0, i, 800));
            gridding.draw(new Line2D.Double(0, i, 800, i));
            String set = Integer.toString(i*100);
            gridding.drawString(set, 400, 400-i);
            set = Integer.toString(i);
            gridding.drawString(set, 400+i, 400);
        }


        /**
         * 绘制坐标轴
         */
        Graphics2D g2 = (Graphics2D) g;
        int centerx = 0;
        int centery = 0;
        int minx = -400;
        int maxx = 400;
        int miny = -400;
        int maxy = 400;
        g2.setColor(Color.red);
        g2.translate(400,400);
        g2.draw(new Line2D.Double(minx,centery,maxx,centery));
        g2.draw(new Line2D.Double(maxx,centery,maxx-5,centery-5));
        g2.draw(new Line2D.Double(maxx,centery,maxx-5,centery+5));
        g2.drawString("X",390,20);

        g2.draw(new Line2D.Double(centerx,miny,centerx,maxy));
        g2.draw(new Line2D.Double(centerx,miny,centerx-5,miny+5));
        g2.draw(new Line2D.Double(centerx,miny,centerx+5,miny+5));
        g2.drawString("Y",-10,-380);



        g2.setColor(Color.black);
        g2.drawString("Y=X*X",5,20);


        int[] arrayy=new int[800];
        int[] arrayx=new int[800];
        arrayx[0]=-400;
        for (int i=0;i<799;i++)
        {
            arrayx[i+1]=arrayx[0]+i;
        }

        for (int i=0;i<800;i++)
        {
            arrayy[i]=-Function(arrayx[i])/100;
        }

        g2.drawPolyline(arrayx,arrayy,800);
    }
    public static int Function(int x){
        return x*x;
    }
}