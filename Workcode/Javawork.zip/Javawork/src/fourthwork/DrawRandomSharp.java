package fourthwork;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Line2D;
import java.util.Random;

import javax.swing.JFrame;


public class DrawRandomSharp extends JFrame
{
    public void launchFrame()
    {
        this.setTitle("Random");
        this.setVisible(true);
        this.setSize(500,500);
        this.setLocation(100,100);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.addWindowFocusListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
    }
    public void paint(Graphics g)
    {

        Random rand = new Random();
        for(int i=0;i<20;i++)
        {

            int x1 = rand.nextInt(500);
            int x2 = rand.nextInt(500);
            int y1 = rand.nextInt(500);
            int y2 = rand.nextInt(500);

            MyLine ML = new MyLine(x1,x2,y1,y2);
            MyRectangle MR = new MyRectangle(x1,x2,y1,y2);
            MyOval MO = new MyOval(x1,x2,y1,y2);

            int x = rand.nextInt(3);
            if(x==0) ML.draw(g);
            if(x==1) MR.draw(g);
            if(x==2) MO.draw(g);

            i++;
        }

    }
    public static void main(String[] args)
    {
        DrawRandomSharp f = new DrawRandomSharp();
        f.launchFrame();

    }
}

abstract class MyShape
{
    int x1,x2,y1,y2;
    public MyShape()
    {
        x1=0;
        x2=0;
        y1=0;
        y2=0;
    }
    public MyShape(int x1,int x2,int y1,int y2)
    {
        this.x1 = x1;
        this.x2 = x2;
        this.y1 = y1;
        this.y2 = y2;
    }
    abstract void draw(Graphics g);
}

class MyLine extends MyShape
{

    public MyLine(int x1,int x2,int y1,int y2)
    {
        super(x1,x2,y1,y2);
    }
    @Override
    void draw(Graphics g)
    {
        g.drawLine(x1,x2,y1,y2);
        g.setColor(Color.red);
    }

}

class MyRectangle extends MyShape
{
    public MyRectangle(int x1,int x2,int y1,int y2)
    {
        super(x1,x2,y1,y2);
    }
    @Override
    void draw(Graphics g)
    {
        g.drawRect(x1,x2,y1,y2);
    }

}
class MyOval extends MyShape
{
    public MyOval(int x1,int x2,int y1,int y2)
    {
        super(x1,x2,y1,y2);
    }
    @Override
    void draw(Graphics g)
    {
        g.drawOval(x1,x2,y1,y2);
    }
}

