package fourthwork;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class JavaClock extends JFrame
{
    private static final long serialVersionUID = 1L;

    public JavaClock()
    {
        ClockPaint cp = new ClockPaint(150, 150, 100);

        this.add(cp);
        this.setSize(500, 500);
        this.setLocation(100, 100);
        this.setTitle("Java Clock");
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.addWindowFocusListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] s)
    {
        new JavaClock();
    }
}

class ClockPaint extends JPanel implements Runnable {

    private static final long serialVersionUID = 1L;
    int x, y, r;
    int h, m, s;// 小时，分钟，秒
    double rad = Math.PI / 180;

    public ClockPaint(int x, int y, int r) {
        this.x = x;
        this.y = y;
        this.r = r;
        Calendar now = new GregorianCalendar();
        s = now.get(Calendar.SECOND) * 6;// 获得秒转换成度数
        m = now.get(Calendar.MINUTE) * 6;// 获得分钟
        h = (now.get(Calendar.HOUR_OF_DAY) - 12) * 30
                + now.get(Calendar.MINUTE) / 12 * 6;// 获得小时

        Thread t = new Thread(this);
        t.start();
    }

    public void paint(Graphics g)
    {


        super.paint(g);
//        g.setColor(Color.WHITE);
//        g.fillRect(0, 0, r * 3, r * 3);

        g.setColor(Color.BLACK);
        g.drawOval(x, y, r * 2, r * 2);

        //秒针
        Graphics2D second = (Graphics2D) g;
        second.setColor(Color.BLACK);
        int x1 = (int) ((r - 10) * Math.sin(rad * s));
        int y1 = (int) ((r - 10) * Math.cos(rad * s));
        g.drawLine(x + r, y + r, x + r + x1, y + r - y1);
        // 分针
        Graphics2D minute = (Graphics2D) g;
        minute.setColor(Color.green);
        x1 = (int) ((r - r / 2.5) * Math.sin(rad * m));
        y1 = (int) ((r - r / 2.5) * Math.cos(rad * m));
        g.drawLine(x + r, y + r, x + r + x1, y + r - y1);
        // 时针
        Graphics2D hour = (Graphics2D) g;
        hour.setColor(Color.blue);
        x1 = (int) ((r - r / 1.5) * Math.sin(rad * h));
        y1 = (int) ((r - r / 1.5) * Math.cos(rad * h));
        g.drawLine(x + r, y + r, x + r + x1, y + r - y1);
        // 数字
        g.setColor(Color.BLACK);
        int d = 29;
        for (int i = 1; i <= 12; i++) {
            x1 = (int) ((r - 10) * Math.sin(rad * d));
            y1 = (int) ((r - 10) * Math.cos(rad * d));
            g.drawString(i + "", x + r + x1 - 4, x + r - y1 + 5);
            d += 30;
        }
        // 小点
        d = 0;
        for (int i = 0; i < 60; i++) {
            x1 = (int) ((r - 2) * Math.sin(rad * d));
            y1 = (int) ((r - 2) * Math.cos(rad * d));
            g.drawString(".", x + r + x1 - 1, x + r - y1 + 1);
            d += 6;
        }

        Graphics2D str = (Graphics2D) g;
        String sec =Integer.toString(s/6);
        if(s<60)
        {
            sec = "0" + sec;
        }
        String min = Integer.toString(m/6);
        if(m<60)
        {
            min = "0" + min;
        }
        String ho = Integer.toString(h/30);
        if(h < 300)
        {
            ho = "0" + ho;
        }
        int fontSize = 20;
        str.setFont(new Font("TimesRoman", Font.PLAIN, fontSize));
        str.drawString(ho + ":" + min + ":" + sec,225, 400 );



    }

    public void run() {
        while (true) {
            try {
                Thread.sleep(1000);
            } catch (Exception ex) {
            }
            s += 6;
            if (s >= 360) {
                s = 0;
                m += 6;
                if (m == 72 || m == 144 || m == 216 || m == 288) {
                    h += 6;
                }
                if (m >= 360) {
                    m = 0;
                    h += 6;
                }
                if (h >= 360) {
                    h = 0;
                }
            }
            this.repaint();
        }
    }
}