package homework;

public class Employee_test
{
    public static void main(String[] args)
    {
        SalariedEmplyee sa_sta = new SalariedEmplyee("Bob", "987654", 12003.5F);
        HourlyEmployee ho_sta = new HourlyEmployee("David", "761235", 300F, 8.5F);
        CommissionEmployee co_sta = new CommissionEmployee("Lisa", "569874", 0.15F, 280000.37F);

        Employee[] staff = new Employee[3];
        staff[0] = sa_sta;
        staff[1] = ho_sta;
        staff[2] = co_sta;

        for(Employee i:staff)
        {
            System.out.println(i.showMessage());
        }
    }
}
