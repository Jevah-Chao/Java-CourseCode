package homework;

public class HourlyEmployee extends Employee
{
    float eachhour_salary;
    float time;

    HourlyEmployee()
    {

    }
    HourlyEmployee(String n, String id, float e, float t)
    {
        super(n, id);
        eachhour_salary = e;
        time = t;
    }

    protected float getSalary()
    {
        return eachhour_salary*time;
    }
    protected String showMessage()
    {
        return "Name: " + super.getName() + " ID: " + super.getID() + " Salary: " + this.getSalary();
    }


}
