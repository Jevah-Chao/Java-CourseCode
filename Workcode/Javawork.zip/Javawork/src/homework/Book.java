package homework;
import java.util.ArrayList;
import java.util.HashMap;

public class Book {
	private String book_name;
	private String ISBN;
	private int book_num;
	private ArrayList<String> student_list;
	private ArrayList<String> author;
	private String language;
	private String press;
	
	public Book(String bn, String i, int n, String[] au, String la, String pr, String[] sl) {
		book_name = bn;
		ISBN = i;
		book_num = n;
		student_list = new ArrayList<String>();
		for(String l: sl)
			student_list.add(l);
		author = new ArrayList<String>();
		for(String a: au)
			author.add(a);
		language = la;
		press = pr;
	}
	
	public Book(String bn, String i, int n, String au, String la, String pr) {
		book_name = bn;
		ISBN = i;
		book_num = n;
		String[] aa = au.split(",");
		author = new ArrayList<String>();
		for(String a: aa)
			author.add(a);
		language = la;
		press = pr;
		student_list = new ArrayList<String>();
	}
	
	public String GetName() {
		return book_name;
	}
	
	public String GetId() {
		return ISBN;
	}
	
	public int GetTotalNum() {
		return book_num;
	}
	
	public ArrayList<String> GetStudentList(){
		return student_list;
	}
	
	public ArrayList<String> GetAuthor(){
		return author;
	}
	
	public HashMap<String, String> GetEssentialInformation(){
		HashMap<String, String> ei = new HashMap<String, String>();
		ei.put("Book", book_name);
		ei.put("Language", language);
		ei.put("Press", press);
		ei.put("ISBN", ISBN);
		String a = new String("");
		for(String au: author) {
			a = a + " " + au; 
		}
		ei.put("Author", a);
		return ei;
	}
	
	public int GetMargin() {
		return book_num - student_list.size();
	}
	
	public String GetLanguage() {
		return language;
	}
	
	public String GetPress() {
		return press;
	}
	public boolean Borrow(Student s) {
		if(s.Borrow(book_name)) {
			if(GetMargin() > 0) {
				student_list.add(s.GetId());
				return true;
			}
			else
				return false;
		}
		return false;
	}
	
	public boolean Return(Student s) {
		if(s.Return(book_name)) {
			student_list.remove(s.GetId());
			return true;
		}
		return false;
	}
}

