package homework;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Calendar;

public class Student {

	private String name;
	private String institution;
	private int age;
	private String gender;
	private String Sid;
	private ArrayList<String> borrow_book_list;

	
	public Student(String n, String id, String i, int a, String g) {
		name = n;
		institution = i;
		Sid = id;
		age = a;
		gender = g;
		borrow_book_list = new ArrayList<String>();

	}
	public String GetName() {
		return name;
	}
	public String GetInstitution() {
		return institution;
	}
	public HashMap<String, String> GetStudentEssentialInformation(){
		HashMap<String, String> ss = new HashMap<String, String>();
		ss.put("Name", name);
		ss.put("Institution", institution);
		ss.put("Gender", gender);
		ss.put("Age", ""+age);
		return ss;
	}
	
	public ArrayList<String> GetBorrowBookList(){
		if(borrow_book_list.isEmpty())
			return null;
		return borrow_book_list;
	}


	
	public boolean Borrow(String n) {
		if(borrow_book_list.contains(n)) {
			System.out.println("You have borrowed this book!");
			return false;
		}
		borrow_book_list.add(n);
		System.out.println("Borrowing successful");
		return true;
	}
	
	public boolean Return(String n) {
		if(!borrow_book_list.contains(n))
		{
			System.out.println("You have not borrowed this book!");
			return false;
		}
		borrow_book_list.remove(n);
		System.out.println("Return successful");
		return true;
	}
	
	public String GetId() {
		return Sid;
	}
}
