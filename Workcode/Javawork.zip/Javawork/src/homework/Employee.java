package homework;

public class Employee
{
    private String name = new String();
    private String ID = new String();

    Employee()
    {

    }
    Employee(String n, String id)
    {
        name = n;
        ID = id;
    }
    protected String getName()
    {
        return this.name;
    }
    protected String getID()
    {
        return this.ID;
    }

    /**
     * 用来给子类重载实现多态
     * @return：无实际含义
     */
    protected float getSalary()
    {
        return 0F;
    }

    protected String showMessage()
    {
        return "Name: " + this.getName() + " ID: " + this.getID();
    }

}
