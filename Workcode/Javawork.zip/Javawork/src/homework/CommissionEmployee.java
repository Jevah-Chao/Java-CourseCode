package homework;

public class CommissionEmployee extends Employee
{
    float bonus;
    float total_sale;

    CommissionEmployee()
    {

    }

    CommissionEmployee(String n, String id, float b, float to)
    {
        super(n, id);
        bonus = b;
        total_sale = to;
    }

    protected float getSalary()
    {
        return bonus*total_sale;
    }
    protected String showMessage()
    {
        return "Name: " + super.getName() + " ID: " + super.getID() + " Salary: " + this.getSalary();
    }
}
