/*

package homework;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.border.*;
import javax.swing.table.*;
import java.util.Arrays;


public class Test{
	
	public static void main(String[] args) {
		HashMap<String, Student> student_list = new HashMap<String, Student>();
		HashMap<String, Book> book_list = new HashMap<String, Book>();
		Student xl = new Student("肖六", "200454", "信息科学与技术学院", 22, "男");
		Student ww = new Student("王五", "200470", "信息科学与技术学院", 22, "男");
		Student zs = new Student("张三", "200003", "信息科学与技术学院", 22, "女");
		Student ls = new Student("李四", "200004", "信息科学与技术学院", 22, "未知");
		student_list.put(xl.GetId(), xl);
		student_list.put(ww.GetId(), ww);
		student_list.put(zs.GetId(), zs);
		student_list.put(ls.GetId(), ls);
		
		Book rjgc = new Book("软件工程", "kajnfjan", 3, "Tim,Kate", "en", "机械工业出版社");
		Book java = new Book("Java", "askfdjaod", 8, "Bob", "cn", "机械工业出版社");
		Book python = new Book("Python", "qpwoerjkf", 9, "CCC", "cn", "机械工业出版社");
		Book MGPA = new Book("Mysetry of GPA", "qwerkqpwe", 0, "Misetricals", "en", "机械工业出版社");
		book_list.put(rjgc.GetName(), rjgc);
		book_list.put(java.GetName(), java);
		book_list.put(python.GetName(), python);
		book_list.put(MGPA.GetName(), MGPA);
		JFrame f = new InitFrame(student_list, book_list);
	}
}
class InitFrame extends JFrame implements ActionListener{
	private JButton borrow_return_book, book_list_button, student_list_button;
	private HashMap<String, Student> student_list;
	private HashMap<String, Book> book_list;
	
	public InitFrame(HashMap<String, Student> sl, HashMap<String, Book> bl) {
		student_list = sl;
		book_list = bl;
		
		setLayout(new FlowLayout());
		
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		this.setSize(500, 500);
		this.setLocation(100, 100);
		
		borrow_return_book = new JButton("借/还书籍");
		book_list_button = new JButton("查询图书清单");
		student_list_button = new JButton("查询学生名单");
		
		this.add(borrow_return_book);
		this.add(book_list_button);
		this.add(student_list_button);
		
		borrow_return_book.addActionListener(this);
		book_list_button.addActionListener(this);
		student_list_button.addActionListener(this);
		
		this.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == borrow_return_book) {
			this.dispose();
			new BRB(student_list, book_list);
		}
		if(e.getSource() == book_list_button) {
			this.dispose();
			new BookListFrame(student_list, book_list);
		}
		if(e.getSource() == student_list_button) {
			this.dispose();
			new StudentListFrame(student_list, book_list);
		}
		
	}
}
class BRB extends JFrame implements ActionListener{
	private JPanel panel = new JPanel();
	private JComboBox cmb = new JComboBox();
	private JLabel label = new JLabel("输入你的学号");
	private JLabel showInfo = new JLabel();
	private JTextField jtf = new JTextField(20);
	private JButton jbtBorrow = new JButton("借书");
	private JButton jbtReturn = new JButton("还书");
	private JButton jbtBack = new JButton("返回");
	private HashMap<String, Student> student_list = new HashMap<String, Student>();
	private HashMap<String, Book> book_list = new HashMap<String, Book>();
	
	public BRB(HashMap<String, Student> sl, HashMap<String, Book> bl){
		super("借/还书");
		student_list = sl;
		book_list = bl;
		
		cmb.addItem("选择你想借的书");
		for(String b: book_list.keySet()) 
			cmb.addItem(b);
		
		panel.add(cmb);
		panel.add(label);
		panel.add(jtf);
		panel.add(jbtBorrow);
		panel.add(jbtReturn);
		panel.add(jbtBack);
		
		this.add(panel);
		jbtBorrow.addActionListener(new MyActionListener());
		jbtReturn.addActionListener(new MyActionListener());
		jbtBack.addActionListener(this);
		cmb.addItemListener(new MyItemListener());
		this.setBounds(100, 100, 500, 500);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == jbtBack) {
			this.dispose();
			new InitFrame(student_list, book_list);
		}
	}
	class MyItemListener implements ItemListener{
		@Override
		public void itemStateChanged(ItemEvent e) {
			String str = e.getItem().toString();
			panel.add(showInfo);
			showInfo.setText("您选择借阅的书籍是：\n" + str);
		}
	}
	class MyActionListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			String command = e.getActionCommand();
			
			if(command.equals("借书")) {
				if(jtf.getText().length() != 0) {
					String book_name = cmb.getSelectedItem().toString();
					if(book_list.get(book_name).GetMargin() > 0 && student_list.containsKey(jtf.getText())) {
						book_list.get(book_name).Borrow(student_list.get(jtf.getText()));
						panel.add(showInfo);
						showInfo.setText("您成功借阅了：" + book_name);
					}
					else {
						panel.add(showInfo);
						showInfo.setText("借阅失败，请检查学号是否输入正确/书籍是否有余量/您是否已经借过这本书了");
					}
				}
				else {
					panel.add(showInfo);
					showInfo.setText("请输入学号");
				}
			}
			
			if(command.equals("还书")) {
				if(jtf.getText().length() != 0) {
					String book_name = cmb.getSelectedItem().toString();
					if(book_list.get(book_name).Return(student_list.get(jtf.getText()))) {
						panel.add(showInfo);
						showInfo.setText("您成功归还了：" + book_name);
					}
					else {
						panel.add(showInfo);
						showInfo.setText("归还失败，请检查学号是否输入正确/您是否借过这本书");
					}
				}
				else {
					panel.add(showInfo);
					showInfo.setText("请输入学号");
				}
			}
		}
	}
}
class BookListFrame extends JFrame implements ActionListener{
	private JPanel contentPane;
	private JTable table;
	private HashMap<String, Student> student_list = new HashMap<String, Student>();
	private HashMap<String, Book> book_list = new HashMap<String, Book>();
	private JButton jbtBack = new JButton("返回");
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == jbtBack) {
			this.dispose();
			new InitFrame(student_list, book_list);
		}
	} 
	
	public BookListFrame(HashMap<String, Student>sl, HashMap<String, Book> bl) {
		student_list = sl;
		book_list = bl;
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				do_this_windowActivated(e);
			}
		});
		
		setTitle("图书信息表");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		contentPane.setLayout(new BorderLayout(0,0));
		
		setContentPane(contentPane);
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		JButton jbtDelete = new JButton("删除");
		JButton jbtExamine = new JButton("查看借书名单");
		JButton jbtIncrease = new JButton("添加");
		jbtIncrease.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_button_actionPerformed(e);
			}
		});
		jbtExamine.addActionListener(new ActionListener() {;
			public void actionPerformed(ActionEvent e) {
				do_button_actionPerformed(e);
			}
		});
		jbtDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_button_actionPerformed(e);
			}
		});
		jbtBack.addActionListener(this);
		panel.add(jbtDelete);
		panel.add(jbtExamine);
		panel.add(jbtIncrease);
		panel.add(jbtBack);
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		table = new JTable();
		
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		scrollPane.setViewportView(table);
		
		this.setVisible(true);
	}
	
	public void do_this_windowActivated(WindowEvent e) {
		DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
		tableModel.setRowCount(0);
		tableModel.setColumnIdentifiers(new Object[] {"书名", "作者", "语言", "出版社", "ISBN", "余量"});
		for(String n:book_list.keySet()) {
			tableModel.addRow(new Object[] {
				book_list.get(n).GetName(), 
				String.join(",", book_list.get(n).GetAuthor()),
				book_list.get(n).GetLanguage(),
				book_list.get(n).GetPress(),
				book_list.get(n).GetId(),
				"" + book_list.get(n).GetMargin()
			});
		}
		table.setRowHeight(30);
		table.setModel(tableModel);
	}
	public void do_button_actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		
		if(command.equals("删除")) {
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			int selectRow = table.getSelectedRow();
			String selectBook = table.getValueAt(selectRow, 0).toString();
			book_list.remove(selectBook);
			model.removeRow(selectRow);
			table.setModel(model);
		}
		if(command.equals("查看借书名单")) {
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			int selectRow = table.getSelectedRow();
			String selectBook = table.getValueAt(selectRow, 0).toString();
			ArrayList<String> sl = book_list.get(selectBook).GetStudentList();
			String show = "";
			for(String n: sl) {
				show = show + n + "\n";
			}
			JOptionPane.showMessageDialog(null, show, "学生名单", JOptionPane.PLAIN_MESSAGE);
		}
		if(command.equals("添加")) {
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			String new_book_name = JOptionPane.showInputDialog("请输入书名：");
			String new_author = JOptionPane.showInputDialog("请输入作者：(多个作者以','隔开)");
			int new_book_num = Integer.parseInt(JOptionPane.showInputDialog("请输入数量："));
			String new_language = JOptionPane.showInputDialog("请输入语言：");
			String new_press = JOptionPane.showInputDialog("请输入出版社：");
			String new_id = JOptionPane.showInputDialog("请输入ISBN：");
			Book newBook = new Book(new_book_name, new_id, new_book_num, new_author, new_language, new_press);
			book_list.put(new_book_name, newBook);
			model.addRow(new Object[] {
				new_book_name, String.join(",", new_author), new_language, new_press, new_id, "" + newBook.GetMargin()
			});
			table.setModel(model);
		}
	}
}
class StudentListFrame extends JFrame implements ActionListener{
	private JPanel contentPane;
	private JTable table;
	private HashMap<String, Student> student_list = new HashMap<String, Student>();
	private HashMap<String, Book> book_list = new HashMap<String, Book>();
	private JButton jbtBack = new JButton("返回");
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == jbtBack) {
			this.dispose();
			new InitFrame(student_list, book_list);
		}
	} 
	
	public StudentListFrame(HashMap<String, Student>sl, HashMap<String, Book> bl) {
		student_list = sl;
		book_list = bl;
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				do_this_windowActivated(e);
			}
		});
		
		setTitle("学生信息表");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		contentPane.setLayout(new BorderLayout(0,0));
		
		setContentPane(contentPane);
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		JButton jbtDelete = new JButton("删除");
		JButton jbtExamine = new JButton("查看借书名单");
		JButton jbtIncrease = new JButton("添加");
		JButton jbtStudent = new JButton("查看学生详细信息");
		jbtIncrease.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_button_actionPerformed(e);
			}
		});
		jbtExamine.addActionListener(new ActionListener() {;
			public void actionPerformed(ActionEvent e) {
				do_button_actionPerformed(e);
			}
		});
		jbtDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_button_actionPerformed(e);
			}
		});
		jbtStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_button_actionPerformed(e);
			}
		});
		jbtBack.addActionListener(this);
		panel.add(jbtDelete);
		panel.add(jbtExamine);
		panel.add(jbtIncrease);
		panel.add(jbtBack);
		panel.add(jbtStudent);
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		table = new JTable();
		
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		scrollPane.setViewportView(table);
		
		this.setVisible(true);
	}
	
	public void do_this_windowActivated(WindowEvent e) {
		DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
		tableModel.setRowCount(0);
		tableModel.setColumnIdentifiers(new Object[] {"姓名", "学号", "学院"});
		for(String n:student_list.keySet()) {
			tableModel.addRow(new Object[] {
				student_list.get(n).GetName(), 
				student_list.get(n).GetId(),
				student_list.get(n).GetInstitution(),
			});
		}
		table.setRowHeight(30);
		table.setModel(tableModel);
	}
	public void do_button_actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		
		if(command.equals("删除")) {
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			int selectRow = table.getSelectedRow();
			String selectStudent = table.getValueAt(selectRow, 1).toString();
			student_list.remove(selectStudent);
			model.removeRow(selectRow);
			table.setModel(model);
		}
		if(command.equals("查看借书名单")) {
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			int selectRow = table.getSelectedRow();
			String selectStudent = table.getValueAt(selectRow, 1).toString();
			ArrayList<String> sl = student_list.get(selectStudent).GetBorrowBookList();
			String show = "";
			for(String n: sl) {
				show = show + n + " 借阅时间：" + student_list.get(selectStudent).GetBorrowTime(n)
						+ " 应在 " + student_list.get(selectStudent).GetReturnTime(n) +" 之前归还 " + "\n";
			}
			JOptionPane.showMessageDialog(null, show, "借书名单", JOptionPane.PLAIN_MESSAGE);
		}
		if(command.equals("添加")) {
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			String new_student_name = JOptionPane.showInputDialog("请输入姓名：");
			int new_age = Integer.parseInt(JOptionPane.showInputDialog("请输入年龄："));
			String new_institution = JOptionPane.showInputDialog("请输入学院：");
			String new_gender = JOptionPane.showInputDialog("请输入性别：");
			String new_id = JOptionPane.showInputDialog("请输入学号：");
			Student newStudent = new Student(new_student_name, new_id, new_institution, new_age, new_gender);
			student_list.put(new_id, newStudent);
			model.addRow(new Object[] {
				new_student_name, new_id, new_institution
			});
			table.setModel(model);
		}
		if(command.equals("查看学生详细信息")) {
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			int selectRow = table.getSelectedRow();
			String selectStudent = table.getValueAt(selectRow, 1).toString();
			Student s = student_list.get(selectStudent);
			HashMap<String, String> information = s.GetStudentEssentialInformation();
			String show = "";
			for(String n: information.keySet()) {
				show = show + n + "：" + information.get(n) + "\n"; 
			}
			JOptionPane.showMessageDialog(null, show, "学生详细信息", JOptionPane.PLAIN_MESSAGE);
		}
	}
}
*/
