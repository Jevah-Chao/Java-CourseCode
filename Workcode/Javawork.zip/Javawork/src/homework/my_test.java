package homework;

import javax.swing.*;
import java.util.HashMap;

public class my_test
{
    public static void main(String[] args) {
        HashMap<String, Student> student_list = new HashMap<String, Student>();
        HashMap<String, Book> book_list = new HashMap<String, Book>();
        Student xm = new Student("小明", "20000001", "信息科学与技术学院", 18, "男");

        student_list.put(xm.GetId(), xm);


        Book Java = new Book("Java", "132456789", 3, "Gary", "Chinese", "电子工业出版社");

        book_list.put(Java.GetName(), Java);

        System.out.println(Java.GetEssentialInformation());

        xm.Borrow("Java");
        xm.Return("Java");

    }
}
