package homework;

public class SalariedEmplyee extends Employee
{
    float salary;
    SalariedEmplyee()
    {

    }

    SalariedEmplyee(String n, String id, float s)
    {
        super(n, id);
        salary = s;
    }

    protected float getSalary()
    {
        return salary;
    }

    protected String showMessage()
    {
        return "Name: " + super.getName() + " ID: " + super.getID() + " Salary: " + this.getSalary();
    }

}
