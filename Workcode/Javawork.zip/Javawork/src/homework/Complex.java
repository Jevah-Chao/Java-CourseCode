package homework;

import javax.swing.JOptionPane;

public class Complex
{
    private double real;
    private double inscriber;

    public static void main(String[] args)
    {
        Complex first = new Complex(1, 1.2);
        Complex second = new Complex(2, 2.4);
        Complex addres = new Complex();
        Complex subres = new Complex();
        addres = first.Add(first, second);
        subres = first.Sub(first, second);




        JOptionPane.showMessageDialog(null, first.Show(second) + "a + b = " + addres.out() +"a - b = " + subres.out(), "结果", JOptionPane.INFORMATION_MESSAGE);

    }


    public Complex()
    {
        // TODO Auto-generated constructor stub

    }


    public Complex(double shi,double xu)
    {
        real = shi;
        inscriber = xu;
    }

    public String Show(Complex b)
    {
        String showString = new String();
        showString = "a = " + this.out() + "b = " + b.out();

        return showString;

    }

    public String out()
    {
        String out = new String();
        if(this.inscriber > 0)
            out = this.real + " + " + this.inscriber + "*i" + '\n';
        else {
            out = this.real + " - " + -1*this.inscriber + "*i" + '\n';
        }

        //System.out.println(out);
        return out;
    }

    public Complex Add(Complex a, Complex b)
    {
        Complex res = new Complex();

        res.real = a.real + b.real;
        res.inscriber = a.inscriber + b.inscriber;
        return res;
    }

    public Complex Sub(Complex a, Complex b)
    {
        Complex res = new Complex();

        res.real = a.real - b.real;
        res.inscriber = a.inscriber - b.inscriber;
        return res;
    }

    public Complex StandardComplex()
    {
        Complex res = new Complex();


        return res;
    }

}

