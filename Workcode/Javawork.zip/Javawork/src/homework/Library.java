/*
package homework;

public class Library
{
    String Book_name = new String();
    Boolean is_lend = fulse;
    String Book_number = new String();
    String Borrow_stu = new String();

    Library()
    {}



}
*/
