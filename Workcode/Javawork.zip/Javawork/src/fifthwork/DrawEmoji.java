package fifthwork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DrawEmoji extends MyFrame
{
    public DrawEmoji()
    {
        mypanel = new JPanel();//创建面板组件
        getContentPane().add(mypanel,BorderLayout.CENTER);
        //先获取默认的内容面板,然后在默认内容面板的BorderLayout.CENTER位置增加frame面板
        mypanel.setLayout(null);//无默认排版
        mypanel.setBounds(0,0,700,700);//面板大小位置
        this.setBounds(0,0,800,800);//设置窗体位置及大小,this可省略
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //用户单击关闭时程序执行
        setTitle("显示表情");//设置窗体标题
        setVisible(true);//设置窗体可见

        //设置文本图片标签
        mylabel = new JLabel("Emoji");
        mylabel.setBounds(90,30,700,250);




        mypanel.add(mylabel);







        mylabel.setBounds(90,30,700,700);

        //mylabel.setIcon(icon1);

        mylabel.setText("请点击按钮");
        mylabel.setFont(new Font(null, Font.PLAIN, 35));
        //设置微笑按钮
        smile = new JButton("微笑");
        mypanel.add(smile);
        smile.setBounds(50,650,60,30);
        smile.addActionListener(new ActionListener()
        {//动作
            public void actionPerformed(ActionEvent e)
            {
                mylabel.setIcon(icon1);
            }
        });
        //设置流泪按钮
        cry = new JButton("流泪");
        mypanel.add(cry);
        cry.setBounds(250,650,60,30);
        cry.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                mylabel.setIcon(icon3);
            }
        });
        //设置生气按钮
        angry = new JButton("生气");
        mypanel.add(angry);
        angry.setBounds(450, 650, 60, 30);
        angry.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                mylabel.setIcon(icon2);
            }
        });
        //退出
        exit = new JButton("退出");
        mypanel.add(exit);
        exit.setBounds(650, 650, 60, 30);
        exit.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                System.exit(0);
            }
        });

        }

        public static void main(String[] args)
        {

            DrawEmoji go = new DrawEmoji();
            if(go.icon1.equals(null))
            {
                JOptionPane.showMessageDialog(null,"woof,woof");
            }
        }
}
