package fifthwork;

import java.awt.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.plaf.multi.MultiPanelUI;


public class GuessNumber extends JFrame
{
    private JPanel mypanel ;
    private JFrame myframe ;
    private JTextField guessfields ;
    private JButton confirm;
    private JButton restart;
    private JButton quit;
    private Integer count = 0;

    GuessNumber()
    {

        int number = 20;


        JFrame frame=new JFrame("Border Layout布局");//JFrame的默认布局管理器为BorderLayout
        frame.setSize(600,400);

        JPanel north = new JPanel();
        JLabel tips = new JLabel("你已经猜了 " + count.toString() + " 次");


        north.add(tips);

        frame.add(north, "North");

        mypanel = new JPanel();
        JLabel field_name = new JLabel("输入要猜测的数");
        mypanel.add(field_name);
        guessfields = new JTextField("0",10);
        mypanel.add(guessfields);
        frame.add(mypanel, "Center");



        JPanel south = new JPanel();
        confirm = new JButton("确定");
        confirm.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e)
            {
                count += 1;
                tips.setText("你已经猜了 " + count.toString() + " 次");
                int get= Integer.parseInt(guessfields.getText().trim());
                System.out.println(get);

                if(get > number)
                {
                    south.setBackground(Color.red);
                    mypanel.setBackground(Color.red);
                    north.setBackground(Color.red);

                }
                else if(get < number)
                {
                    south.setBackground(Color.blue);
                    mypanel.setBackground(Color.blue);
                    north.setBackground(Color.blue);

                }
                else
                {
                    JOptionPane.showMessageDialog(null,"恭喜你猜对了", "Message",JOptionPane.WARNING_MESSAGE);
                }

            }
        });
        south.add(confirm);
        restart = new JButton("重新开始");
        restart.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e)
            {
                count = 0;
                tips.setText("你已经猜了 " + count.toString() + " 次");
                guessfields.setText("0");
                south.setBackground(Color.white);
                mypanel.setBackground(Color.white);
                north.setBackground(Color.white);
            }
        });
        south.add(restart);


        quit = new JButton("退出");
        quit.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {

                System.exit(0);
            }
        });
        south.add(quit);

        frame.add(south,"South");



//        getContentPane().add(mypanel,BorderLayout.CENTER);
        frame.setBounds(550, 250, 400, 200);//设置窗体位置及大小,this可省略
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //用户单击关闭时程序执行
        frame.setTitle("猜数");//设置窗体标题
        frame.setVisible(true);//设置窗体可见
    }

    public static void main(String[] args) {
        GuessNumber my = new GuessNumber();
    }

}
