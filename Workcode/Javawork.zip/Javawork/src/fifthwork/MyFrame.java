package fifthwork;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;


public class MyFrame extends JFrame {

    JPanel mypanel;
    JButton smile;
    JButton cry;
    JButton angry;
    JButton exit;
    JLabel mylabel;
    ImageIcon icon1 = new ImageIcon("E:\\Javawork\\smile.png");
    ImageIcon icon2 = new ImageIcon("E:\\Javawork\\angry.png");
    ImageIcon icon3 = new ImageIcon("E:\\Javawork\\cry.png");

}
